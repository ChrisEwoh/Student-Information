﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

using _1004_Assignment_Project;

//StudentRegistration.Start(@"C:\Users\16473\my_codes\studentdata.json");

//StudentRegistration.JSONDeserializer(@"C:\Users\16473\student.json");

//StudentService studentservice = new StudentService();
//studentservice.readAllStudentFromFile();

//StudentReg.Start(@"C:\Users\16473\my_codes\studentdata.txt");

//password pss = new password();
//pss.Passwordset();

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  StudentPortal.StartReg(@"C:\Users\16473\1004grp_file\studentdata.txt");

//StudentPortal.StartReg(@"C:\Users\16473\1004grp_file\coursedata.txt");
